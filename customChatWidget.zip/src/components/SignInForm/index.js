// import React, { useState, useContext } from "react";
// import { useAppConfig } from "../../providers/AppConfigProvider";
// import { chatWithFormStates } from "../../constants";
// import { genLogger } from "../../lib/logger";
// import {
//   SignInContainer,
//   SignInTitle,
//   OptionContainer,
//   OptionButton,
//   InputField,
//   HelpText,
//   SignInButton,
//   RadioInput,
//   RequiredMark,
//   InputLabel,
// } from "./styled";

// const name = "SignInForm";
// const { log } = genLogger(name);

// const SignInForm = ({ setData, setCurrentState }) => {
//   const { primaryColor } = useAppConfig();
//   const [signInMethod, setSignInMethod] = useState("email");
//   const [inputValue, setInputValue] = useState("");

//   const handleSignIn = () => {
//     if (signInMethod === "email" && !inputValue.includes("@")) {
//       log("Invalid email format");
//       return;
//     } else if (signInMethod === "sms" && !/^\+?\d{10,}$/.test(inputValue)) {
//       log("Invalid phone number format");
//       return;
//     }
//     log("Sign in with:", signInMethod, inputValue);
//     setData((prev) => ({
//       ...prev,
//       signInMethod,
//       signInValue: inputValue,
//     }));
//     setCurrentState(chatWithFormStates.CHAT_WIDGET);
//   };

//   return (
//     <SignInContainer id="chat-container">
//       <SignInTitle>Sign in</SignInTitle>
//       <OptionContainer>
//         <OptionButton active={signInMethod === "email"}>
//           <RadioInput
//             type="radio"
//             name="signInMethod"
//             value="email"
//             checked={signInMethod === "email"}
//             onChange={() => setSignInMethod("email")}
//           />
//           <span>Email</span>
//         </OptionButton>

//         <OptionButton active={signInMethod === "sms"}>
//           <RadioInput
//             type="radio"
//             name="signInMethod"
//             value="sms"
//             checked={signInMethod === "sms"}
//             onChange={() => setSignInMethod("sms")}
//           />
//           <span>SMS</span>
//         </OptionButton>
//       </OptionContainer>
//       <InputLabel
//         id="phone-label"
//         data-testid="phone-label"
//         htmlFor="signInInput"
//       >
//         {signInMethod === "email" ? "Your email" : "Your phone number"}
//         <RequiredMark>*</RequiredMark>
//       </InputLabel>

//       <InputField
//         id="signInInput"
//         type={signInMethod === "email" ? "email" : "tel"}
//         placeholder={
//           signInMethod === "email" ? "Your email*" : "Your phone number*"
//         }
//         value={inputValue}
//         onChange={(e) => setInputValue(e.target.value)}
//       />

//       <HelpText>Can't sign in? Send us a message</HelpText>
//       <SignInButton onClick={handleSignIn}>Sign In</SignInButton>
//     </SignInContainer>
//   );
// };

// export default SignInForm;

import React, { useState } from "react";
import { useAppConfig } from "../../providers/AppConfigProvider";
import { chatWithFormStates, device } from "../../constants";
import { genLogger } from "../../lib/logger";
import { FaAngleLeft } from "react-icons/fa6";
import { LuClock } from "react-icons/lu";
import {
  SignInContainer,
  OfflineNotice,
  HeaderWrapper,
  SignInContent,
  SignInTitle,
  OptionContainer,
  OptionButton,
  InputField,
  HelpText,
  SignInButton,
  RadioInput,
  RequiredMark,
  InputLabel,
} from "./styled";

const name = "SignInForm";
const { log } = genLogger(name);

const SignInForm = ({ setData, setCurrentState }) => {
  const { primaryColor } = useAppConfig();
  const [signInMethod, setSignInMethod] = useState("email");
  const [inputValue, setInputValue] = useState("");

  const handleSignIn = () => {
    if (signInMethod === "email" && !inputValue.includes("@")) {
      log("Invalid email format");
      return;
    } else if (signInMethod === "sms" && !/^\+?\d{10,}$/.test(inputValue)) {
      log("Invalid phone number format");
      return;
    }
    log("Sign in with:", signInMethod, inputValue);
    setData((prev) => ({
      ...prev,
      signInMethod,
      signInValue: inputValue,
    }));
    setCurrentState(chatWithFormStates.CHAT_WIDGET);
  };

   const startChatDirectly = (text) => {
      log("Start chat button clicked with text:", text);
      setData((prev) => ({
        ...prev,
        chatTopic: text,
      }));
      setCurrentState(chatWithFormStates.CHAT_WIDGET);
    };

  return (
    // JSX
    <SignInContainer id="chat-container" device={device}>
      <HeaderWrapper>
        <span onClick={() => setCurrentState(chatWithFormStates.FORM)} style={{ cursor: "pointer" }}>
          <FaAngleLeft />
        </span>
        <OfflineNotice>
          Ruff Greens Help Desk <br />
          <span className="back-online">
            <LuClock /> 
            <span>Back online at 5:00 PM</span>{" "}
          </span>
        </OfflineNotice>
      </HeaderWrapper>

      <SignInContent>
        <SignInTitle primaryColor={primaryColor}>Sign in</SignInTitle>

        <OptionContainer>
          <OptionButton
            active={signInMethod === "email"}
            primaryColor={primaryColor}
          >
            <RadioInput
              type="radio"
              name="signInMethod"
              value="email"
              checked={signInMethod === "email"}
              onChange={() => setSignInMethod("email")}
            />
            <span>Email</span>
          </OptionButton>

          <OptionButton
            active={signInMethod === "sms"}
            primaryColor={primaryColor}
          >
            <RadioInput
              type="radio"
              name="signInMethod"
              value="sms"
              checked={signInMethod === "sms"}
              onChange={() => setSignInMethod("sms")}
            />
            <span>SMS</span>
          </OptionButton>
        </OptionContainer>

        <InputLabel htmlFor="signInInput">
          {signInMethod === "email" ? "Your email" : "Your phone number"}
          <RequiredMark>*</RequiredMark>
        </InputLabel>

        <InputField
          id="signInInput"
          type={signInMethod === "email" ? "email" : "tel"}
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          primaryColor={primaryColor}
        />

        <HelpText>Can't sign in? {" "} 
          <span   onClick={() => startChatDirectly(" Send us a message")}>
            Send us a message
            </span>
          </HelpText>

        <SignInButton onClick={handleSignIn} primaryColor={primaryColor}>
          Sign In
        </SignInButton>
      </SignInContent>
    </SignInContainer>
  );
};

export default SignInForm;
