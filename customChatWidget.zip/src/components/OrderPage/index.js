import React, { useState } from "react";
import {
  PageWrapper,
  OrderCard,
  OrderHeader,
  SectionTitle,
  OrderId,
  OrderPrice,
  Shipment,
  CancelledTag,
  ReportButton,
  ProductWrapper,
  ProductImage,
  ProductInfo,
  ProductTitle,
  ProductPrice,
  Footer,
  HelpText,
  MessageButton,

} from "./styled"; 

const OrdersPage = ({ orders }) => {
  const [reportButtonToggle, setReportButtonToggle] = useState(false)
  if (!Array.isArray(orders) || orders.length === 0) {
    return <p>No orders found</p>;
  }

  const reportHandler = ()=>{
    setReportButtonToggle(true)
  }
  const helpOptions = [
  { id: 1, text: "I'd like to get a refund for this order", hide: true },
  { id: 2, text: "I'd like to reorder some items", hide: true },
  { id: 3, text: "Other", hide: true }
];

  return (
    <>
    {reportButtonToggle ? (<OptionsContainer>
            <OptionList device={device}>
              {helpOptions.map((option) => (
                <OptionButton
                  className="optionbutton"
                  key={option.id}
                  type="button"
                  onClick={() => startChatDirectly(option)}
                >
                  {option.text} <FaGreaterThan />
                </OptionButton>
              ))}
            </OptionList>
          </OptionsContainer>): (<><PageWrapper>
    
      <SectionTitle>Your orders</SectionTitle>
      {orders.map((order) => (
        <OrderCard key={order.id}>
          <OrderHeader>
            <OrderId>Order {order.name}</OrderId>
            <OrderPrice>
              ${order.totalPriceSet.shopMoney.amount}{" "}
              {order.totalPriceSet.shopMoney.currencyCode}
            </OrderPrice>
          </OrderHeader>

          <Shipment>
            Shipment
            {order.displayFulfillmentStatus === "CANCELLED" && (
              <CancelledTag>Cancelled</CancelledTag>
            )}
          </Shipment>

          <ReportButton onClick={()=>{ reportHandler()}}>Report issue</ReportButton>

          {order.lineItems.edges.map(({ node }) => (
            <ProductWrapper key={node.title}>
              <ProductImage src={node.image?.url} alt={node.title} />
              <ProductInfo>
                <ProductTitle>{node.title}</ProductTitle>
                <ProductPrice>
                  ${order.totalPriceSet.shopMoney.amount} x {node.quantity}
                </ProductPrice>
              </ProductInfo>
            </ProductWrapper>
          ))}
        </OrderCard>
      ))}
    </PageWrapper>
      <Footer>
        <HelpText>Need more help?</HelpText>
        <MessageButton>Send Us A Message</MessageButton>
      </Footer></>)}
   
      </>
  );
};

export default OrdersPage;

